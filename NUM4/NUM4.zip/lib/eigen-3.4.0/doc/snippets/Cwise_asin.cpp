Array3d v(0, sqrt(2.)/2, 1);
cout << v.asin() << endl;
